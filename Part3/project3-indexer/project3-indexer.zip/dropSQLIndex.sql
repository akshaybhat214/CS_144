#Akshay Bhat and Aditya Padmakumar

DROP INDEX sp_index ON ItemLatLong; #No built-in IF EXITS modifier
DROP TABLE IF EXISTS ItemLatLong;