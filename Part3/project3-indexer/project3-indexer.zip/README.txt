#Akshay Bhat and Aditya Padmakumar
#2/13/2016

We would like to use one of our late days for this assignment.

We created Lucene indices on Items.ItemId, Items.Name ,Items.Description and 
Categories.Category. Creating inverted indices on text fields is how we
minimized query times.
We also created a spacial index (R-tree) on the Latitude and Longitude fields.